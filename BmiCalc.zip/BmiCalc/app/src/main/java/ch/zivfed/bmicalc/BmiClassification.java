package ch.zivfed.bmicalc;

public enum BmiClassification {
    UNDERWEIGHT,
    NORMALWEIGHT,
    PREOBESITY,
    OBESITY1,
    OBESITY2,
    OBESITY3
}
